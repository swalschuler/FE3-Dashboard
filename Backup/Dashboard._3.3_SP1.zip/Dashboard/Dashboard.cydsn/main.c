/*******************************************************************************
* File Name: main.c
*
* Version: 1.0
*
* Description:
*  This example project demonstrates how to configure the CAN Component in
*  the Full CAN mode.
*  The CAN component is configured to receive the following messages from the
*  remote node:
*   Message 1 - Status of Switch 1.
*   Message 2 - ADC data.
*
*  The component is also configured to transmit data to control the pulse width
*  of the PWM in the remote node. The transmitted data (pulse width value)
*  increments at a switch press.
*  Both transmitted and received data are displayed on a 2x16 LCD.
*
*  This is only one part of the CAN example project. Use this along with
*  CAN_Basic_Example for complete demonstration.
*
* Hardware Dependency:
*  CY8CKIT-001
*  CY8CKIT-017
*
********************************************************************************
* Copyright 2015, Cypress Semiconductor Corporation. All rights reserved.
* This software is owned by Cypress Semiconductor Corporation and is protected
* by and subject to worldwide patent and copyright laws and treaties.
* Therefore, you may use this software only as provided in the license agreement
* accompanying the software package from which you obtained this software.
* CYPRESS AND ITS SUPPLIERS MAKE NO WARRANTY OF ANY KIND, EXPRESS OR IMPLIED,
* WITH REGARD TO THIS SOFTWARE, INCLUDING, BUT NOT LIMITED TO, NONINFRINGEMENT,
* IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE.
*******************************************************************************/
#include <project.h>
#include <stdio.h>
#include "can_manager.h"

#define PWM_PULSE_WIDTH_STEP        (10u)
#define SWITCH_PRESSED              (0u)
#define PWM_MESSAGE_ID              (0x1AAu)
#define PWM_MESSAGE_IDE             (0u)    /* Standard message */
#define PWM_MESSAGE_IRQ             (0u)    /* No transmit IRQ */
#define PWM_MESSAGE_RTR             (0u)    /* No RTR */
#define CAN_RX_MAILBOX_0_SHIFT      (1u)
#define CAN_RX_MAILBOX_1_SHIFT      (2u)
#define DATA_SIZE                   (6u)
#define ONE_BYTE_OFFSET             (8u)

/* Function prototypes */
//CY_ISR_PROTO(ISR_CAN);

/* Global variables used to store configuration and data for BASIC CAN mailbox */
//CAN_DATA_BYTES_MSG dataPWM;
//CAN_TX_MSG messagePWM;

/* Global variable used to store PWM pulse width value */
//uint8 pulseWidthValue = 0u;

/* Global variable used to store receive message mailbox number */
//volatile uint8 receiveMailboxNumber = 0xFFu;

typedef enum 
{
	Startup,
	LV,
	Precharging,
	HV_Enabled,
	Drive,
	Fault
    
}Dash_State;

typedef enum 
{
	OK,
	fromLV,
	fromPrecharging,
	fromHV_Enabled,
	fromDrive,
    fromFault
    
}Error_State;

/* Switch state defines -- Active High*/ 
#define SWITCH_ON         (1u)
#define SWITCH_OFF        (0u)
/* Switch debounce delay in milliseconds */
#define SWITCH_DEBOUNCE_UNIT   (1u)
/* Number of debounce units to count delay, before consider that switch is pressed */
#define SWITCH_DEBOUNCE_PERIOD (10u)
/* Function prototypes */
static uint32 ReadSwSwitch(void);

/* Global variable used to store switch state */
uint8 HVSwitch = SWITCH_OFF;
uint8 DriveSwitch = SWITCH_OFF;

void test_inject(DataPacket *data_queue, uint16_t *data_tail)
{
	//inject message to test usb
	// NOTE: does not handle queue wrapping. Assumes queue has room.
	data_queue[*data_tail].millicounter = 0;
	data_queue[*data_tail].id = 0x111;
	data_queue[*data_tail].length = 8;
	data_queue[*data_tail].data[0]= 0;
	data_queue[*data_tail].data[1]= 1;
	data_queue[*data_tail].data[2]= 2;
	data_queue[*data_tail].data[3]= 3;
	data_queue[*data_tail].data[4]= 4;
	data_queue[*data_tail].data[5]= 5;
	data_queue[*data_tail].data[6]= 6;
	data_queue[*data_tail].data[7]= 0x7E;
	(*data_tail)++; // does not handle queue wrapping.
} // test_inject()


/*******************************************************************************
* Function Name: main
********************************************************************************
*
* Summary:
*  main() performs the following functions:
*  1: Initializes a structure for the Basic CAN mailbox to send messages.
*  2: Starts the CAN and LCD components.
*  3: When received Message 1, sends the PWM pulse width and displays
*     received switch status and value of PWM pulse width on an LCD; 
*     When received Message 2, display received ADC data on an LCD.
*
* Parameters:
*  None.
*
* Return:
*  None.
*
*******************************************************************************/

int main()
{   
    Dash_State state = Startup;
    Error_State error_state = OK;
    
    // Main data queue
	DataPacket data_queue[DATA_QUEUE_LENGTH];
	uint16_t data_head, data_tail;
	data_head = data_tail = 0;
    
    //Tach Meter Stuff
    uint8_t value=0; // replace the value with 
    int8_t direction=1;
    WaveDAC8_1_Start();
    
    //precharging time counter
    uint32_t PrechargingTimeCount = 0;
    
    //Initialize CAN
    ////CAN_GlobalIntEnable();
    ////CAN_Init();
    ////CAN_Start();
    
    /* Set CAN interrupt handler to local routine */
    //CyIntSetVector(CAN_ISR_NUMBER, ISR_CAN);    

    ////CyGlobalIntEnable;
    
    //while(1){
    //}
    
    //char8 txData[DATA_SIZE];
    //uint16 adcData;
    
    /* BASIC CAN mailbox configuration */
    //messagePWM.dlc = CAN_TX_DLC_MAX_VALUE;
    //messagePWM.id  = PWM_MESSAGE_ID;
    //messagePWM.ide = PWM_MESSAGE_IDE;
    //messagePWM.irq = PWM_MESSAGE_IRQ;
    //messagePWM.msg = &dataPWM;
    //messagePWM.rtr = PWM_MESSAGE_RTR;

    ////LCD_Start();

    
    /* Display value of ADC output on LCD */
    //LCD_Position(0u, 0u);
    //LCD_PrintString("ADC");

    /* Display state of switch on LCD */
    //LCD_Position(1u, 0u);
    //LCD_PrintString("SW");

    /* Display state of PWM pulse width on LCD */
    //LCD_Position(0u, 10u);
    //LCD_PrintString("PWM");

    //test_inject(data_queue, &data_tail);
    
    for(;;)
    {
        LED_Write(~LED_ReadDataReg());
/*        
        can_send_cmd(0x1234,
		0x5678,
		0x9012);
        
        CyDelay(100);
        
        can_send_status(0x0000,
		0x0000,
		0x0000);
        
        CyDelay(100);
        
        
        can_get(data_queue, &data_head, &data_tail); // clears queue before filling
    
        LCD_Position(0u, 0u);
        LCD_PrintInt16(data_queue[0].id);
    
        LCD_Position(1u, 0u);
        LCD_PrintInt8(data_queue[0].data[0]);
    
        LCD_Position(0u, 10u);
        LCD_PrintInt8(data_queue[0].data[1]);
*/        

/*
    Startup,
	LV,
	Precharging,
	HV_Enabled,
	Drive,
	Fault
*/       
        
        switch(state)
        {
            case Startup:
                
                
                
                //Initialize CAN
                CAN_GlobalIntEnable();
                CAN_Init();
                CAN_Start();
                
                can_send_status(state);

                CyGlobalIntEnable;
                
                LCD_Start();
                
                //UI
                
                Buzzer_Write(1);
                WaveDAC8_1_SetValue(253);
                CyDelay(2000);
                
                //RGB Testing
                RGB3_1_Write(1);
                CyDelay(200);
                RGB3_1_Write(0);
                RGB2_1_Write(1);
                CyDelay(200);
                RGB2_1_Write(0);
                RGB1_1_Write(1);
                CyDelay(200);
                RGB1_1_Write(0);
                RGB3_2_Write(1);
                CyDelay(200);
                RGB3_2_Write(0);
                RGB2_2_Write(1);
                CyDelay(200);
                RGB2_2_Write(0);
                RGB1_2_Write(1);
                CyDelay(200);
                RGB1_2_Write(0);
                
                Buzzer_Write(0);
                WaveDAC8_1_SetValue(0);
                
                state = LV;
                
            break;
                
            case LV:
                
                //can_send_cmd(1,0,0); 
        
                can_get(data_queue, &data_head, &data_tail); // clears queue before filling
    
                
                
                LCD_Position(1u, 10u);
                LCD_PrintInt16(data_queue[0].id);
                
                uint16_t temp = can_read(data_queue, data_head, data_tail, 0x07FF, 0);
                
                LCD_Position(0u, 0u);
                LCD_PrintInt16(temp);
                
                temp = can_read(data_queue, data_head, data_tail, 0x07FF, 1);
                LCD_Position(1u, 0u);
                LCD_PrintInt8(temp);
                
                temp = can_read(data_queue, data_head, data_tail, 0x07FF, 2);
                LCD_Position(0u, 10u);
                LCD_PrintInt8(temp);
                
                //UI
                
                Buzzer_Write(0);
                
                
                //
                // RGB code goes here
                // pick a color
                
                if (Drive_Read())
                {
                    state = Fault;
                    error_state = fromLV;
                    break;
                }
            
                if (HV_Read())    /* Switch state changed status */
                {
                    state = Precharging;
                } 
                
            break;
                
            case Precharging:
                   
                Buzzer_Write(1);
                can_send_cmd(1,0,0); // setInterlock
                
                can_get(data_queue, &data_head, &data_tail); // clears queue before filling
                uint8_t MainState = can_read(data_queue, data_head, data_tail, 0x0566, 0);
                uint8_t CapacitorVolt = can_read(data_queue, data_head, data_tail, 0x0566, 1);
                uint8_t NomialVolt =  can_read(data_queue, data_head, data_tail, 0x0566, 2);
                
                if(NomialVolt > 90) // need to be tuned
                    state = HV_Enabled;
                
                PrechargingTimeCount++;
                
                if (PrechargingTimeCount == 5)
                {
                    state = Fault;
                    error_state = fromPrecharging;
                }
                
                CyDelay(2000);
                    
            break;
	        
            case HV_Enabled:
                //
                // RGB code goes here
                // Blue
                
                Buzzer_Write(0);
                
                if (Drive_Read())
                {
                    can_get(data_queue, &data_head, &data_tail); // clears queue before filling
                    if(can_read(data_queue, data_head, data_tail, 0x0766, 2)>100) // 100 for error tolerance
                        state = Drive;
                    else
                    {
                        state = Fault;
                        error_state = fromHV_Enabled;
                        break;
                    }                     
                }
                
                if(!HV_Read())
                    state = LV;
            break;
                
	        case Drive:
                
                //
                // RGB code goes here
                // Green
                
                Buzzer_Write(0);
                
                can_get(data_queue, &data_head, &data_tail); // clears queue before filling
                uint8_t ABS_Motor_RPM = can_read(data_queue, data_head, data_tail, 0x0566, 4);
                uint16_t Throttle = can_read(data_queue, data_head, data_tail, 0x0123, 0); // use 123 for pedal node place holder
                uint16_t Brake = can_read(data_queue, data_head, data_tail, 0x0123, 1);
                
                WaveDAC8_1_SetValue(ABS_Motor_RPM);
                can_send_cmd(1,Throttle,Brake); // setInterlock
                
                //check if everything is going well
                can_get(data_queue, &data_head, &data_tail); // clears queue before filling
                uint8_t ACK = can_read(data_queue, data_head, data_tail, 0x0666, 0);
                
                if ((ACK != 0xFF) | 
                    (!Curtis_Heart_Beat_Check(data_queue, data_head, data_tail)) |
                    (Curtis_Fault_Check(data_queue, data_head,data_tail)))
                {
                    state = Fault;
                    error_state = fromDrive;
                    break;
                }
                
                if (!HV_Read())
                    state = LV;
                
                if (!Drive_Read())
                    state = HV_Enabled;
                
                    
                // need to map ABS_Motor_RPM into 1-253 scale.
                
                /*
                if (ABS_Motor_RPM>=253)
                {
                    direction=-1;
                }
                else if (ABS_Motor_RPM<=1)
                {
                    direction=1;
                }
                value+=direction;
                //CyDelay(100);
                */
            break;
                
	        case Fault:
                //
                // RGB code goes here
                // flashing red
                Buzzer_Write(0);
                
                if(error_state == fromLV)
                {
                    if(!Drive_Read())
                    {
                        state = LV;
                        error_state = OK;
                    }
                }
                else if (error_state == fromHV_Enabled)
                {
                    if(!Drive_Read())
                    {
                        state = HV_Enabled;
                        error_state = OK;
                    }
                }
                else if (error_state == fromDrive)
                {
                    can_get(data_queue, &data_head, &data_tail); // clears queue before filling
                    
                    // Curtis Come back online again without error
                    if(!Curtis_Fault_Check(data_queue,data_head,data_tail) 
                       & Curtis_Heart_Beat_Check(data_queue, data_head, data_tail))
                    {
                        state = LV;
                        error_state = OK;
                    }
                    else if(0xFF == can_read(data_queue, data_head, data_tail, 0x0666, 0)) //ACK received
                    {
                        state = HV_Enabled;
                        error_state = OK;
                    }                   
                }
            break;

        }
        
        can_send_status(state);
        
        //if (receiveMailboxNumber == CAN_RX_MAILBOX_switchStatus)
        //{
            //LCD_Position(1u, 3u);
            //send
            //if (CAN_RX_DATA_BYTE1(CAN_RX_MAILBOX_switchStatus) == SWITCH_PRESSED)
            //{
                /* Display received switch status on LCD */
            
                //LCD_PrintString("pressed ");

                /* Increase the PWM pulse width */
                //pulseWidthValue += PWM_PULSE_WIDTH_STEP;

                /* Send message with the new PWM pulse width */
                //dataPWM.byte[0u] = pulseWidthValue;
                //CAN_SendMsg(&messagePWM);

                /* Display value of PWM pulse width on LCD */
                //LCD_Position(0u, 14u);
                //LCD_PrintInt8(pulseWidthValue);

            //}
            //else
            //{
                /* Display received switch status on LCD */
            //    LCD_PrintString("released");
            //}
            //receiveMailboxNumber = 0xFFu;
        //}
        
        //received

        //if (receiveMailboxNumber == CAN_RX_MAILBOX_ADCdata)
        //{
        //    adcData = ((uint16) ((uint16) CAN_RX_DATA_BYTE1(CAN_RX_MAILBOX_ADCdata) << ONE_BYTE_OFFSET)) | 
        //    CAN_RX_DATA_BYTE2(CAN_RX_MAILBOX_ADCdata);
            
            /* Display received ADC data on LCD */
       //     sprintf(txData, "%u.%.3u", (adcData / 1000u), (adcData % 1000u));
        //    txData[DATA_SIZE - 1u] = (char8) '\0';
            
        //    LCD_Position(0u, 4u);
         //   LCD_PrintString(txData);
         //   receiveMailboxNumber = 0xFFu;
        //}
    }
}

/*
// 0 for HV, 1 for Drive
static uint32 ReadSwSwitch(uint8_t choice)
{
    uint32 heldDown;
    uint32 swStatus;

    swStatus = 0u;  // Switch is not active 
    heldDown = 0u;  // Reset debounce counter

    
    if (choice)
        swStatus = Drive_Read();
    else
        swStatus = HV_Read();

    return (swStatus);
}
*/
/*******************************************************************************
* Function Name: ISR_CAN
********************************************************************************
*
* Summary:
*  This ISR is executed at a Receive Message event and set receiveMailboxNumber
*  global variable with receive message mailbox number.
*
* Parameters:
*  None.
*
* Return:
*  None.
*
*******************************************************************************/
CY_ISR(ISR_CAN)
{   
    /* Clear Receive Message flag */
    CAN_INT_SR_REG.byte[1u] = CAN_RX_MESSAGE_MASK;

    /* Set the isrFlag */
    //isrFlag = 1u;    

    /* Acknowledges receipt of new message */
    CAN_RX_ACK_MESSAGE(CAN_RX_MAILBOX_0);

    ///* Clear Receive Message flag */
    //CAN_INT_SR_REG.byte[1u] = CAN_RX_MESSAGE_MASK;
    /* Switch Status message received */
   // if ((CY_GET_REG16((reg16 *) &CAN_BUF_SR_REG.byte[0u]) & CAN_RX_MAILBOX_0_SHIFT) != 0u)
   // {        
   //     receiveMailboxNumber = CAN_RX_MAILBOX_switchStatus;

        /* Acknowledges receipt of new message */
   //     CAN_RX_ACK_MESSAGE(CAN_RX_MAILBOX_switchStatus);
   // }

    /* ADC data message received */
   // if ((CY_GET_REG16((reg16 *) &CAN_BUF_SR_REG.byte[0u]) & CAN_RX_MAILBOX_1_SHIFT) != 0u)
   // {
   //     receiveMailboxNumber = CAN_RX_MAILBOX_ADCdata;

        /* Acknowledges receipt of new message */
   //     CAN_RX_ACK_MESSAGE(CAN_RX_MAILBOX_ADCdata);
   // }
}

/* [] END OF FILE */

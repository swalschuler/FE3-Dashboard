var DC998A_8ino =
[
    [ "loop", "DC998A_8ino.html#a39a24a80bc3128a314bb15c85fc22cef", null ],
    [ "main_menu_1_continuous_mode", "DC998A_8ino.html#a64ac82fbeafab36f3d017541e83a2d93", null ],
    [ "main_menu_2_read_and_clear_faults", "DC998A_8ino.html#a21a7f586f5a34f884cd877b5d29abf5f", null ],
    [ "main_menu_3_send_ARA", "DC998A_8ino.html#a1c050a7c14e6462a777174b7952e3942", null ],
    [ "main_menu_4_manage_alerts", "DC998A_8ino.html#a4672deb86f6c626dbd1ac5702125f387", null ],
    [ "main_menu_5_settings", "DC998A_8ino.html#ac0e044c0550f11947d1e7a9efea16dfd", null ],
    [ "main_menu_6_read_all_registers", "DC998A_8ino.html#a9c0356b14b53a531d65b4b1b47596fa2", null ],
    [ "print_main_menu", "DC998A_8ino.html#a91617cf4981e38a2bb10a1992738b86b", null ],
    [ "print_title", "DC998A_8ino.html#a0b879bb0b1ef45ad46fc8331c59225f9", null ],
    [ "setup", "DC998A_8ino.html#a90de5b68ab8defa635679fc0620fb698", null ],
    [ "ack_error", "DC998A_8ino.html#af44aa0a7af52c0e91b3f5ec0908c0a93", null ],
    [ "adin_lsb", "DC998A_8ino.html#a8a2d36355a49edea7a515f6d9e7a8347", null ],
    [ "current_lsb", "DC998A_8ino.html#aba386b925bf5ce95f042af152fa66978", null ],
    [ "demo_board_connected", "DC998A_8ino.html#a6b6612d3ffc7cc8c4a57d8d0ba6d80d4", null ],
    [ "resistive_ratio", "DC998A_8ino.html#a3091bc819b7103453e77271b8e860d3b", null ],
    [ "resistor", "DC998A_8ino.html#a3f654af35a4ccdf340741afe3eec62e7", null ]
];
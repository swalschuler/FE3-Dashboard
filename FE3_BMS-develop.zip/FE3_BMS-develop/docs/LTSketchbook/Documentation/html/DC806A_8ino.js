var DC806A_8ino =
[
    [ "loop", "DC806A_8ino.html#a39a24a80bc3128a314bb15c85fc22cef", null ],
    [ "menu_1_read_single_ended", "DC806A_8ino.html#a6c11b4744e3281567214bf2460eaa60f", null ],
    [ "menu_2_read_differential", "DC806A_8ino.html#a8fc7f997a791eba6e1a8d8c1b44f2a89", null ],
    [ "menu_3_read_single_ended_com7", "DC806A_8ino.html#a3d5ac1df15df921364f7fa798abab6eb", null ],
    [ "menu_4_calibrate", "DC806A_8ino.html#a1c8ee84b0126263a1c0294e4e4b73007", null ],
    [ "menu_5_sleep", "DC806A_8ino.html#a04aec2fe9c60183b298fffb8ee1970ca", null ],
    [ "menu_6_select_uni_bipolar", "DC806A_8ino.html#a34237042ba487f114b341c1bc291fd50", null ],
    [ "print_prompt", "DC806A_8ino.html#a2ea477f9f0e79d6865887e79570ac386", null ],
    [ "print_title", "DC806A_8ino.html#a0b879bb0b1ef45ad46fc8331c59225f9", null ],
    [ "print_user_command", "DC806A_8ino.html#af1418f97589cbd2395d1d1769d29298b", null ],
    [ "restore_calibration", "DC806A_8ino.html#a8a2c607e019908d9e92698fa842e0c28", null ],
    [ "setup", "DC806A_8ino.html#a90de5b68ab8defa635679fc0620fb698", null ],
    [ "store_calibration", "DC806A_8ino.html#a7c5befd5ab914622919e68a8af53edd2", null ],
    [ "BUILD_COMMAND_DIFF", "DC806A_8ino.html#acc623b3551359dcf8e66b344f86ad61e", null ],
    [ "BUILD_COMMAND_SINGLE_ENDED", "DC806A_8ino.html#ac3dac851080025c8dfd854b08c7242f2", null ],
    [ "BUILD_COMMAND_SINGLE_ENDED_COM7", "DC806A_8ino.html#a00813d66a18bc06cb66bdf0b4ed81b34", null ],
    [ "demo_board_connected", "DC806A_8ino.html#a1371f3fcb5f0942f131a857d01f04f93", null ],
    [ "LTC1867_lsb", "DC806A_8ino.html#ab2351e0cc2231ac78b991e4076327932", null ],
    [ "LTC1867_offset_bipolar_code", "DC806A_8ino.html#a6ff340b8a92d244d406c78d7224da7d1", null ],
    [ "LTC1867_offset_unipolar_code", "DC806A_8ino.html#a12756b6ca8717dc2a51b24d43bbdf4cf", null ],
    [ "uni_bi_polar", "DC806A_8ino.html#a3428f7cd2d91b49f202d3b2c72da41ef", null ]
];
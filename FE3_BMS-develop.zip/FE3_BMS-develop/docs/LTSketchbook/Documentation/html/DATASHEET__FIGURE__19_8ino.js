var DATASHEET__FIGURE__19_8ino =
[
    [ "configure_channels", "DATASHEET__FIGURE__19_8ino.html#a4db6dc6482453443a198b8e2cbb1fcb2", null ],
    [ "configure_global_parameters", "DATASHEET__FIGURE__19_8ino.html#af1c27f60a3f5bf845a7684b47a774c5b", null ],
    [ "loop", "DATASHEET__FIGURE__19_8ino.html#a39a24a80bc3128a314bb15c85fc22cef", null ],
    [ "setup", "DATASHEET__FIGURE__19_8ino.html#a90de5b68ab8defa635679fc0620fb698", null ]
];
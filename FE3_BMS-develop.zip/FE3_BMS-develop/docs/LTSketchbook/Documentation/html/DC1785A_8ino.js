var DC1785A_8ino =
[
    [ "loop", "DC1785A_8ino.html#a39a24a80bc3128a314bb15c85fc22cef", null ],
    [ "menu_1_single_ended_voltage", "DC1785A_8ino.html#a31155a6de38efde836d1d0264e250934", null ],
    [ "menu_2_read_differential_voltage", "DC1785A_8ino.html#a0472515fc4718d1aec5cb4d558159151", null ],
    [ "menu_3_read_temperature", "DC1785A_8ino.html#a9b66de1f4cd44e0b793a4f5870708dd5", null ],
    [ "menu_4_settings", "DC1785A_8ino.html#a07f3dadf795013af400915476a63f529", null ],
    [ "menu_5_pwm_options", "DC1785A_8ino.html#a26a8eee21e11d21060eb983ca6a2816a", null ],
    [ "print_prompt", "DC1785A_8ino.html#a2ea477f9f0e79d6865887e79570ac386", null ],
    [ "print_title", "DC1785A_8ino.html#a0b879bb0b1ef45ad46fc8331c59225f9", null ],
    [ "setup", "DC1785A_8ino.html#a90de5b68ab8defa635679fc0620fb698", null ],
    [ "demo_board_connected", "DC1785A_8ino.html#a1371f3fcb5f0942f131a857d01f04f93", null ],
    [ "LTC2991_TIMEOUT", "DC1785A_8ino.html#ad9d9565f8a38bc112393b1fa12d5d8d9", null ]
];
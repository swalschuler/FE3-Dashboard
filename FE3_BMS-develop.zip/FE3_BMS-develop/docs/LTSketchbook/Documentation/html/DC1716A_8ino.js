var DC1716A_8ino =
[
    [ "loop", "DC1716A_8ino.html#a39a24a80bc3128a314bb15c85fc22cef", null ],
    [ "menu_1_read_differential", "DC1716A_8ino.html#ad1b12456208caf0da46dc7be1a8a4701", null ],
    [ "menu_2_set_sps", "DC1716A_8ino.html#a4c4fcd68725e79792642f6071f1aac5b", null ],
    [ "menu_3_sleep", "DC1716A_8ino.html#ab36d5a24a53f5b8c061fbbaadbf5445d", null ],
    [ "menu_4_set_address", "DC1716A_8ino.html#ad46a6fa3e1c3afe55ef730251b1e0d41", null ],
    [ "print_prompt", "DC1716A_8ino.html#a2ea477f9f0e79d6865887e79570ac386", null ],
    [ "print_title", "DC1716A_8ino.html#a0b879bb0b1ef45ad46fc8331c59225f9", null ],
    [ "print_user_command", "DC1716A_8ino.html#af1418f97589cbd2395d1d1769d29298b", null ],
    [ "setup", "DC1716A_8ino.html#a90de5b68ab8defa635679fc0620fb698", null ],
    [ "i2c_address", "DC1716A_8ino.html#afd5dbf719bae2b1ea9260a55e7c289cf", null ],
    [ "LTC2473_vref", "DC1716A_8ino.html#afde407a8e8eb065e381556941a2262ce", null ],
    [ "timeout", "DC1716A_8ino.html#a7f1ad43d3bf79b40bc39dbb5a6c3a5ae", null ]
];
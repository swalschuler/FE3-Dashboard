var DC726B_8ino =
[
    [ "loop", "DC726B_8ino.html#a39a24a80bc3128a314bb15c85fc22cef", null ],
    [ "manually_set_reg", "DC726B_8ino.html#a15721590d45a52ace00c5096dd7a39d3", null ],
    [ "print_prompt", "DC726B_8ino.html#a2ea477f9f0e79d6865887e79570ac386", null ],
    [ "print_title", "DC726B_8ino.html#a0b879bb0b1ef45ad46fc8331c59225f9", null ],
    [ "set_frequency", "DC726B_8ino.html#a864a77fede135b88b088560555cee95c", null ],
    [ "settings", "DC726B_8ino.html#a4b2eb9b1717bb7d76209b7c1de9aa0cb", null ],
    [ "setup", "DC726B_8ino.html#a90de5b68ab8defa635679fc0620fb698", null ],
    [ "output_config", "DC726B_8ino.html#a19274fea2fad587a5d4069ddaf8db9f2", null ]
];
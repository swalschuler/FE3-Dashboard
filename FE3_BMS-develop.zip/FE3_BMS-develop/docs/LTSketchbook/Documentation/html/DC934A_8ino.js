var DC934A_8ino =
[
    [ "get_code", "DC934A_8ino.html#aae6d7a8645db319871666bb3dc4fb017", null ],
    [ "get_voltage", "DC934A_8ino.html#a1666d069c4a8d20b1076a0bbfaa73f51", null ],
    [ "loop", "DC934A_8ino.html#a39a24a80bc3128a314bb15c85fc22cef", null ],
    [ "menu_1_select_dac", "DC934A_8ino.html#a1ea670d43efee7446269d147fcfed824", null ],
    [ "menu_2_write_to_input_register", "DC934A_8ino.html#a98b825048417a53e6b346526fe3e8963", null ],
    [ "menu_3_write_and_update_dac", "DC934A_8ino.html#ad44c52a8607f0316b6e9abfef134608e", null ],
    [ "menu_4_update_power_up_dac", "DC934A_8ino.html#aef6192c51d16a4502db5a52a9cab5817", null ],
    [ "menu_5_power_down_dac", "DC934A_8ino.html#aa8e7ab9267585428cf7558913a1276f1", null ],
    [ "menu_6_read_adc", "DC934A_8ino.html#ad7a66171a936418553a5c7875449fb74", null ],
    [ "menu_7_sweep", "DC934A_8ino.html#afa8d820bc96843eeb916addf78524352", null ],
    [ "menu_8_calibrate_all", "DC934A_8ino.html#a66e3409c77d63f68b10ac520ca701832", null ],
    [ "print_prompt", "DC934A_8ino.html#a7f35c539c4379e0574c42f51bf61c43e", null ],
    [ "print_title", "DC934A_8ino.html#a0b879bb0b1ef45ad46fc8331c59225f9", null ],
    [ "prompt_voltage_or_code", "DC934A_8ino.html#aa9565fd9bf138f09ef7788d0c4d59d48", null ],
    [ "setup", "DC934A_8ino.html#a90de5b68ab8defa635679fc0620fb698", null ],
    [ "prompt", "DC934A_8ino.html#ad84e19307a43d3f799a4daeef0a6484a", [
      [ "PROMPT_VOLTAGE", "DC934A_8ino.html#ad84e19307a43d3f799a4daeef0a6484aade5fdbe90accb6c380a3b8058ce81061", null ],
      [ "PROMPT_CODE", "DC934A_8ino.html#ad84e19307a43d3f799a4daeef0a6484aa9a7854699f83b2901c4aa1ae65d9a024", null ]
    ] ],
    [ "address_map", "DC934A_8ino.html#abfb06ea039c2d5233e81f872cf17f53c", null ],
    [ "demo_board_connected", "DC934A_8ino.html#a6b6612d3ffc7cc8c4a57d8d0ba6d80d4", null ],
    [ "LTC2422_lsb", "DC934A_8ino.html#af74f11df227b2accf8c8f03cfdf0261d", null ],
    [ "LTC2422_TIMEOUT", "DC934A_8ino.html#ac8a6d1ed5b91f03b8338363b13e4fe4e", null ],
    [ "LTC2607_lsb", "DC934A_8ino.html#aad2f8c49503c59b0142da7aea92a62c1", null ],
    [ "LTC2607_offset", "DC934A_8ino.html#af2cb1f1b2dc632f96df1ae1d5ae79722", null ],
    [ "MISO_TIMEOUT", "DC934A_8ino.html#a50ab9ab49e31bd464fa19c7959cb6c73", null ]
];
var DC570A_8ino =
[
    [ "loop", "DC570A_8ino.html#a39a24a80bc3128a314bb15c85fc22cef", null ],
    [ "menu_1_read_differential", "DC570A_8ino.html#ab43105789febb97334c44e5837343c41", null ],
    [ "menu_2_set_OSR", "DC570A_8ino.html#a88724ebe193058081c5139384a0a6f03", null ],
    [ "menu_set_OSR", "DC570A_8ino.html#a680048d8d06b2c4cc678388ca9ffdd88", null ],
    [ "print_prompt", "DC570A_8ino.html#a2ea477f9f0e79d6865887e79570ac386", null ],
    [ "print_title", "DC570A_8ino.html#a0b879bb0b1ef45ad46fc8331c59225f9", null ],
    [ "print_user_command", "DC570A_8ino.html#af1418f97589cbd2395d1d1769d29298b", null ],
    [ "setup", "DC570A_8ino.html#a90de5b68ab8defa635679fc0620fb698", null ],
    [ "demo_board_connected", "DC570A_8ino.html#a1371f3fcb5f0942f131a857d01f04f93", null ],
    [ "LTC2440_vref", "DC570A_8ino.html#a1f77c039ab86a266737a30d21a1cd48f", null ],
    [ "OSR_mode", "DC570A_8ino.html#acec1dbcba72e6a75a2df1ba695aa2047", null ]
];
var DC1339A_8ino =
[
    [ "loop", "DC1339A_8ino.html#a39a24a80bc3128a314bb15c85fc22cef", null ],
    [ "menu_1_read_input", "DC1339A_8ino.html#a566d3e9aaa73069867f553dea44c455c", null ],
    [ "menu_2_select_uni_bipolar", "DC1339A_8ino.html#a39b248b4b6edd8222df307237f15d3c2", null ],
    [ "print_prompt", "DC1339A_8ino.html#a2ea477f9f0e79d6865887e79570ac386", null ],
    [ "print_title", "DC1339A_8ino.html#a0b879bb0b1ef45ad46fc8331c59225f9", null ],
    [ "setup", "DC1339A_8ino.html#a90de5b68ab8defa635679fc0620fb698", null ],
    [ "LTC2302_vref", "DC1339A_8ino.html#a5cf899d17f8c7f4c81a157b3d9e86802", null ],
    [ "uni_bipolar", "DC1339A_8ino.html#a852ea918b861ab8327bb393038d17568", null ]
];
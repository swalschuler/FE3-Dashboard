var DC1208A_8ino =
[
    [ "loop", "DC1208A_8ino.html#a39a24a80bc3128a314bb15c85fc22cef", null ],
    [ "LTC4151_snapshot", "DC1208A_8ino.html#a97e6fa2d82c8a4171ac689cfb281c9e6", null ],
    [ "menu_1_continuous_mode", "DC1208A_8ino.html#af65523ff28747f8a8a4ec7dc351528b4", null ],
    [ "menu_2_snapshot_mode", "DC1208A_8ino.html#a513ab39f050acae255e171533e41098e", null ],
    [ "print_prompt", "DC1208A_8ino.html#a2ea477f9f0e79d6865887e79570ac386", null ],
    [ "print_title", "DC1208A_8ino.html#a0b879bb0b1ef45ad46fc8331c59225f9", null ],
    [ "setup", "DC1208A_8ino.html#a90de5b68ab8defa635679fc0620fb698", null ],
    [ "demo_board_connected", "DC1208A_8ino.html#a6b6612d3ffc7cc8c4a57d8d0ba6d80d4", null ],
    [ "LTC4151_adin_lsb", "DC1208A_8ino.html#a7be8168775cbb4645bcb61624c870e14", null ],
    [ "LTC4151_sense_lsb", "DC1208A_8ino.html#a0aeceb3059a7fb50c2f62b7b29844783", null ],
    [ "LTC4151_vin_lsb", "DC1208A_8ino.html#a299bf86210dee8aea67e2b53b6d29ccf", null ],
    [ "resistor", "DC1208A_8ino.html#a3f654af35a4ccdf340741afe3eec62e7", null ]
];
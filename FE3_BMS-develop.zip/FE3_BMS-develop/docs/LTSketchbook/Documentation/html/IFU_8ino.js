var IFU_8ino =
[
    [ "loop", "IFU_8ino.html#a39a24a80bc3128a314bb15c85fc22cef", null ],
    [ "program", "IFU_8ino.html#a10b4693afe90a251e3caa3bf50739597", null ],
    [ "readVout", "IFU_8ino.html#acf0f2b18d948fa1ce387e9e802e325f8", null ],
    [ "setup", "IFU_8ino.html#a90de5b68ab8defa635679fc0620fb698", null ],
    [ "mainMenu", "IFU_8ino.html#ac88afb6e2db7f9c8fa98d388bd1dbf65", null ],
    [ "pmbus", "IFU_8ino.html#a56d8d6b829d638afabaa5e61cce0801d", null ],
    [ "smbusNoPec", "IFU_8ino.html#af0ae7db6ea4a49d71dee3f2893f49605", null ],
    [ "smbusPec", "IFU_8ino.html#ac6214ca252b34700e09f6b6292e021f0", null ]
];
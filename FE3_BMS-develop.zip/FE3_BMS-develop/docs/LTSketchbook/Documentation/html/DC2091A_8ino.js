var DC2091A_8ino =
[
    [ "loop", "DC2091A_8ino.html#a39a24a80bc3128a314bb15c85fc22cef", null ],
    [ "menu_1_read_register", "DC2091A_8ino.html#a0dc3a44df64fd6f92a90ce8fd16d1efb", null ],
    [ "menu_2_write_register", "DC2091A_8ino.html#a164d3d079b57967970d4ae3bad4f5c43", null ],
    [ "print_prompt", "DC2091A_8ino.html#a2ea477f9f0e79d6865887e79570ac386", null ],
    [ "print_title", "DC2091A_8ino.html#a0b879bb0b1ef45ad46fc8331c59225f9", null ],
    [ "print_user_command", "DC2091A_8ino.html#af1418f97589cbd2395d1d1769d29298b", null ],
    [ "setup", "DC2091A_8ino.html#a90de5b68ab8defa635679fc0620fb698", null ],
    [ "address", "DC2091A_8ino.html#af3f726014b044194def151079f1f2d89", null ],
    [ "rw", "DC2091A_8ino.html#a820f12447415f64f4233b3e383380b3d", null ]
];
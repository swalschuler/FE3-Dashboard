var DC572A_8ino =
[
    [ "change_range", "DC572A_8ino.html#a6c197e5eb072f614dd7d2d0d100d997d", null ],
    [ "loop", "DC572A_8ino.html#a39a24a80bc3128a314bb15c85fc22cef", null ],
    [ "print_prompt", "DC572A_8ino.html#a2ea477f9f0e79d6865887e79570ac386", null ],
    [ "print_title", "DC572A_8ino.html#a0b879bb0b1ef45ad46fc8331c59225f9", null ],
    [ "setup", "DC572A_8ino.html#a90de5b68ab8defa635679fc0620fb698", null ],
    [ "square_wave_output", "DC572A_8ino.html#ab242f606fa8565419207e1a70e6153f7", null ],
    [ "voltage_output", "DC572A_8ino.html#a5bc05ec3bec03099f53766b48f93a27f", null ],
    [ "choice", "DC572A_8ino.html#adbb1827d8937b862bbeb5a841e8740eb", null ],
    [ "data", "DC572A_8ino.html#aa6e451eccf9519b0809baad41f5ab241", null ],
    [ "demo_board_connected", "DC572A_8ino.html#a1371f3fcb5f0942f131a857d01f04f93", null ],
    [ "RANGE_HIGH", "DC572A_8ino.html#a542c153518fe5384740ca857551552de", null ],
    [ "RANGE_LOW", "DC572A_8ino.html#a9f6cd92e5fc485b83be0d0aff29260a9", null ]
];
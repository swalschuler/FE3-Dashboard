var DC1976A_8ino =
[
    [ "demo_board_option", "DC1976A_8ino.html#a59c54ff88800d9cd564522cef34778d6", null ],
    [ "loop", "DC1976A_8ino.html#a39a24a80bc3128a314bb15c85fc22cef", null ],
    [ "LTC3676_print_all_registers", "DC1976A_8ino.html#a2912c2eaf4a3c5f8a2a88a875a4d1506", null ],
    [ "menu_1_read_write_registers", "DC1976A_8ino.html#a72f314c33a46d0f2b6ed5941a0a8527e", null ],
    [ "menu_2_regulator_settings", "DC1976A_8ino.html#a711d476572072952ef67b6d2b35bb466", null ],
    [ "menu_3_control_settings", "DC1976A_8ino.html#a43551c894abaf1ab3006e5ffb70479a9", null ],
    [ "menu_4_sequencing", "DC1976A_8ino.html#a7bb59dfcf48d3aab85029059427ba986", null ],
    [ "print_prompt", "DC1976A_8ino.html#a2ea477f9f0e79d6865887e79570ac386", null ],
    [ "print_title", "DC1976A_8ino.html#a0b879bb0b1ef45ad46fc8331c59225f9", null ],
    [ "print_warning_prompt", "DC1976A_8ino.html#a7eba913bde59a1c1972f731a7586f393", null ],
    [ "read_reg_map", "DC1976A_8ino.html#a7efd352c35cd8bfa0566d04dc0a489f3", null ],
    [ "setup", "DC1976A_8ino.html#a90de5b68ab8defa635679fc0620fb698", null ],
    [ "board_option", "DC1976A_8ino.html#a6d9075d6f1afbb76ee91796d4c4de6aa", null ],
    [ "delay_ms", "DC1976A_8ino.html#ae9e9bf17e37a05572bcc2a576565122e", null ],
    [ "demo_board_connected", "DC1976A_8ino.html#a1371f3fcb5f0942f131a857d01f04f93", null ],
    [ "demo_name", "DC1976A_8ino.html#a6c112de8121ca3229273371855103456", null ],
    [ "i2c_address", "DC1976A_8ino.html#afd5dbf719bae2b1ea9260a55e7c289cf", null ],
    [ "reg_phase", "DC1976A_8ino.html#ac0c3076252ded0343ac3a592782c6c29", null ]
];
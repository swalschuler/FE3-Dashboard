var DC571A_8ino =
[
    [ "loop", "DC571A_8ino.html#a39a24a80bc3128a314bb15c85fc22cef", null ],
    [ "menu_1_read_single_ended", "DC571A_8ino.html#a26323c9b1c91dfe3fdbb4d00d8766fdf", null ],
    [ "menu_2_read_differential", "DC571A_8ino.html#afae568c0df1a91394c078376683156b8", null ],
    [ "menu_3_calibrate", "DC571A_8ino.html#a288f429dc75bc254db045983a4581435", null ],
    [ "print_prompt", "DC571A_8ino.html#a2ea477f9f0e79d6865887e79570ac386", null ],
    [ "print_title", "DC571A_8ino.html#a0b879bb0b1ef45ad46fc8331c59225f9", null ],
    [ "print_user_command", "DC571A_8ino.html#af1418f97589cbd2395d1d1769d29298b", null ],
    [ "restore_calibration", "DC571A_8ino.html#a8a2c607e019908d9e92698fa842e0c28", null ],
    [ "setup", "DC571A_8ino.html#a90de5b68ab8defa635679fc0620fb698", null ],
    [ "store_calibration", "DC571A_8ino.html#a7c5befd5ab914622919e68a8af53edd2", null ],
    [ "BUILD_COMMAND_DIFF", "DC571A_8ino.html#aecd2bef5a7980968bf536307e3ecbb14", null ],
    [ "BUILD_COMMAND_SINGLE_ENDED", "DC571A_8ino.html#a089db05417baced654c68d2539ff1002", null ],
    [ "demo_board_connected", "DC571A_8ino.html#a1371f3fcb5f0942f131a857d01f04f93", null ],
    [ "LTC2418_lsb", "DC571A_8ino.html#af8f1fe7c48d603fea87069f2493afb0f", null ],
    [ "LTC2418_offset_code", "DC571A_8ino.html#a40d5f9c85aaef351c511ab7c3cb730c4", null ],
    [ "MISO_TIMEOUT", "DC571A_8ino.html#a50ab9ab49e31bd464fa19c7959cb6c73", null ]
];
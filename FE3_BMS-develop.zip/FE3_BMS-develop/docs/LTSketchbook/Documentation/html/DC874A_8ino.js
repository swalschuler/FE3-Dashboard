var DC874A_8ino =
[
    [ "loop", "DC874A_8ino.html#a39a24a80bc3128a314bb15c85fc22cef", null ],
    [ "main_menu_1_continuous_mode", "DC874A_8ino.html#a64ac82fbeafab36f3d017541e83a2d93", null ],
    [ "main_menu_2_read_and_clear_faults", "DC874A_8ino.html#a21a7f586f5a34f884cd877b5d29abf5f", null ],
    [ "main_menu_3_send_ARA", "DC874A_8ino.html#a1c050a7c14e6462a777174b7952e3942", null ],
    [ "main_menu_4_manage_alerts", "DC874A_8ino.html#a4672deb86f6c626dbd1ac5702125f387", null ],
    [ "main_menu_5_settings", "DC874A_8ino.html#ac0e044c0550f11947d1e7a9efea16dfd", null ],
    [ "main_menu_6_read_all_registers", "DC874A_8ino.html#a9c0356b14b53a531d65b4b1b47596fa2", null ],
    [ "print_prompt", "DC874A_8ino.html#a2ea477f9f0e79d6865887e79570ac386", null ],
    [ "print_title", "DC874A_8ino.html#a0b879bb0b1ef45ad46fc8331c59225f9", null ],
    [ "setup", "DC874A_8ino.html#a90de5b68ab8defa635679fc0620fb698", null ],
    [ "SENSE_RESISTOR", "DC874A_8ino.html#a496fcc3f7b622fa51e9cc9b7629c0ba8", null ]
];
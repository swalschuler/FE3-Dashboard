var DoxygenExample_8ino =
[
    [ "function1", "DoxygenExample_8ino.html#a33f43af788525a69c27820cb5ecb6a59", null ],
    [ "function2", "DoxygenExample_8ino.html#aad72f1e70c4b9eaa810a0c7e87733e79", null ],
    [ "loop", "DoxygenExample_8ino.html#a39a24a80bc3128a314bb15c85fc22cef", null ],
    [ "setup", "DoxygenExample_8ino.html#a90de5b68ab8defa635679fc0620fb698", null ],
    [ "var1", "DoxygenExample_8ino.html#aca73699eb673d080ff1be53f42eb5ad8", null ],
    [ "var2", "DoxygenExample_8ino.html#ac0da06d47d79ad4b9fb1c0eaf1118c3f", null ]
];